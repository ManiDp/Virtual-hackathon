# Virtual-Hackathon
Data Analysis on COVID-19

Students       Roll
Varun.B.G      19BCS111
V.Manideep     19BCS112

Number of students in group=2
